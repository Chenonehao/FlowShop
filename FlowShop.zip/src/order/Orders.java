package order;

import java.util.ArrayList;

public class Orders {
    public static ArrayList<Order> orders = new ArrayList<>();
}
